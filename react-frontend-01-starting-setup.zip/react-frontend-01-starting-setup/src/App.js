import React from 'react';

function App() {
  return <h1>Let's start!</h1>;
}

export default App;
